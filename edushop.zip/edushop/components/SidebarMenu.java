import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.util.HashMap;

public class SidebarMenu extends JPanel {

    public interface Navigator {
        void navigate(String sectionName);
    }

    private final HashMap<String, JPanel> items = new HashMap<>();
    private String selectedItem = "";

    // Colors
    private final Color BG_COLOR = new Color(95, 0, 160);
    private final Color ITEM_BG = new Color(120, 30, 220);
    private final Color HOVER_BG = new Color(150, 70, 230);
    private final Color SELECTED_BG = new Color(130, 40, 250);
    private final Color TEXT_COLOR = Color.WHITE;

    public SidebarMenu(Navigator navigator) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(BG_COLOR);
        setBorder(new EmptyBorder(10, 0, 10, 0));

        add(Box.createVerticalStrut(20));

        addItem("Dashboard", "🏠", navigator);
        addItem("My Courses", "📚", navigator);
        addItem("Cart", "🛒", navigator);
        addItem("Profile", "👤", navigator);
        addItem("Settings", "⚙️", navigator);

        add(Box.createVerticalGlue());
    }

    private void addItem(String name, String iconText, Navigator navigator) {
        JPanel item = new JPanel();
        item.setLayout(new FlowLayout(FlowLayout.LEFT, 15, 10));
        item.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        item.setBackground(ITEM_BG);
        item.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        JLabel icon = new JLabel(iconText);
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 18));
        icon.setForeground(TEXT_COLOR);

        JLabel label = new JLabel(name);
        label.setFont(new Font("Segoe UI", Font.BOLD, 16));
        label.setForeground(TEXT_COLOR);

        item.add(icon);
        item.add(label);

        // Hover & click effects
        item.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (!name.equals(selectedItem)) item.setBackground(HOVER_BG);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                if (!name.equals(selectedItem)) item.setBackground(ITEM_BG);
            }
            @Override
            public void mouseClicked(MouseEvent e) {
                selectItem(name);
                navigator.navigate(name);
            }
        });

        items.put(name, item);
        add(item);
        add(Box.createVerticalStrut(5));
    }

    public void selectItem(String name) {
        selectedItem = name;
        for (String key : items.keySet()) {
            JPanel item = items.get(key);
            if (key.equals(name)) {
                item.setBackground(SELECTED_BG);
            } else {
                item.setBackground(ITEM_BG);
            }
        }
    }
}
