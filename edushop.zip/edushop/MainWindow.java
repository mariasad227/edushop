import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

import Cart.ShoppingCartPage;
import courses.MyCoursesPage;

public class MainWindow extends JFrame {

    private final CardLayout contentCards = new CardLayout();
    private final JPanel contentPanel = new JPanel(contentCards);

    private SidebarMenu sidebar;

    private final ShoppingCartPage cartPage = new ShoppingCartPage();

    // Theme colors
    private final Color PURPLE = Color.decode("#8117eb");
    private final Color PURPLE_DARK = new Color(95, 0, 160);
    private final Color PURPLE_LIGHT = new Color(150, 70, 230);
    private final Color HEADER_BG = PURPLE_DARK;
    private final Color FOOTER_BG = PURPLE;
    private final Color BUTTON_BG = PURPLE;
    private final Color BUTTON_HOVER = PURPLE_LIGHT;

    public MainWindow() {
        super("EduShop — Learn Anywhere, Anytime");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 700);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        add(createTopBar(), BorderLayout.NORTH);

        // Sidebar
        sidebar = new SidebarMenu(section -> showCard(section));

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, sidebar, createContentPanel());
        split.setDividerLocation(260);
        split.setOneTouchExpandable(false);
        add(split, BorderLayout.CENTER);

        add(createFooter(), BorderLayout.SOUTH);

        sidebar.selectItem("Dashboard");
    }

    private JComponent createTopBar() {
        JPanel top = new JPanel(new BorderLayout(10, 10));
        top.setBackground(HEADER_BG);
        top.setBorder(new EmptyBorder(10, 12, 10, 12));

        // ---- LOAD LOGO ----
        ImageIcon rawIcon = new ImageIcon(getClass().getResource("/courses/images/logo.png"));
        Image scaledImg = rawIcon.getImage().getScaledInstance(32, 32, Image.SCALE_SMOOTH);
        JLabel logoLabel = new JLabel(new ImageIcon(scaledImg));
        logoLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        // ---- BRAND TEXT ----
        JLabel brand = new JLabel("EduShop");
        brand.setFont(new Font("Segoe UI", Font.BOLD, 20));
        brand.setForeground(Color.WHITE);
        brand.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        // ---- CLICK ACTION (logo + text) ----
        MouseAdapter goHome = new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                showCard("Dashboard");
                sidebar.selectItem("Dashboard");
            }
        };
        logoLabel.addMouseListener(goHome);
        brand.addMouseListener(goHome);

        // ---- BRAND PANEL (logo + text) ----
        JPanel brandPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        brandPanel.setOpaque(false);
        brandPanel.add(logoLabel);
        brandPanel.add(brand);

        top.add(brandPanel, BorderLayout.WEST);

        // ---- ACTION BUTTONS (e.g., CART) ----
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        actions.setOpaque(false);

        JButton cartBtn = new JButton("Cart");
        styleButton(cartBtn);
        cartBtn.addActionListener(e -> {
            cartPage.refresh();
            showCard("Cart");
            sidebar.selectItem("Cart");
        });

        actions.add(cartBtn);
        top.add(actions, BorderLayout.EAST);

        return top;
    }

    private void styleButton(JButton button) {
        button.setBackground(BUTTON_BG);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 12));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(BUTTON_HOVER);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(BUTTON_BG);
            }
        });
    }

    private JComponent createContentPanel() {
        contentPanel.setBorder(new EmptyBorder(12, 12, 12, 12));
        contentPanel.setBackground(Color.WHITE);

        contentPanel.add(makeDashboardPanel(), "Dashboard");
        contentPanel.add(new MyCoursesPage(), "My Courses");
        contentPanel.add(cartPage, "Cart");
        contentPanel.add(makeProfilePanel(), "Profile");
        contentPanel.add(makeSettingsPanel(), "Settings");

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.add(contentPanel, BorderLayout.CENTER);
        return wrapper;
    }

    private JPanel basePanel(String title) {
        JPanel p = new JPanel(new BorderLayout(8, 8));
        p.setBackground(Color.WHITE);
        JLabel lbl = new JLabel(title);
        lbl.setFont(lbl.getFont().deriveFont(Font.BOLD, 18f));
        lbl.setForeground(PURPLE_DARK);
        p.add(lbl, BorderLayout.NORTH);
        return p;
    }

    private JPanel makeDashboardPanel() {
        JPanel p = basePanel("Dashboard");
        JLabel lbl = new JLabel("Welcome to EduShop! Browse courses and start learning.");
        lbl.setForeground(Color.DARK_GRAY);
        p.add(lbl, BorderLayout.CENTER);
        return p;
    }

    private JPanel makeProfilePanel() {
        JPanel p = basePanel("Profile");
        JLabel lbl = new JLabel("User profile goes here.");
        lbl.setForeground(Color.DARK_GRAY);
        p.add(lbl, BorderLayout.CENTER);
        return p;
    }

    private JPanel makeSettingsPanel() {
        JPanel p = basePanel("Settings");
        JLabel lbl = new JLabel("Settings panel.");
        lbl.setForeground(Color.DARK_GRAY);
        p.add(lbl, BorderLayout.CENTER);
        return p;
    }

    public void showCard(String name) {
        contentCards.show(contentPanel, name);
    }

    private JComponent createFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(FOOTER_BG);
        footer.setBorder(new EmptyBorder(8, 12, 8, 12));

        JLabel lbl = new JLabel("© 2025 EduShop");
        lbl.setForeground(Color.WHITE);
        footer.add(lbl, BorderLayout.WEST);

        return footer;
    }
}
