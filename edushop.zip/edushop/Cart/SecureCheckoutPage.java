package Cart;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SecureCheckoutPage extends JFrame {

    Color PURPLE = Color.decode("#8117eb");
    Color PURPLE_LIGHT = new Color(150, 70, 230);

    // Store field references here for easy access
    private RoundedTextField nameField;
    private RoundedTextField emailField;
    private RoundedTextField phoneField;
    private RoundedTextField addressField;

    public SecureCheckoutPage(double total) {

        setTitle("Secure Checkout");
        setSize(480, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel main = new JPanel();
        main.setBackground(Color.WHITE);
        main.setLayout(new BoxLayout(main, BoxLayout.Y_AXIS));
        main.setBorder(new EmptyBorder(20, 30, 20, 30));

        // HEADER
        JLabel title = new JLabel("Secure Checkout");
        title.setFont(new Font("Arial", Font.BOLD, 26));
        title.setForeground(PURPLE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel sub = new JLabel("Total to Pay: " + total + " DA");
        sub.setFont(new Font("Arial", Font.PLAIN, 18));
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);

        main.add(title);
        main.add(Box.createVerticalStrut(10));
        main.add(sub);
        main.add(Box.createVerticalStrut(20));

        // FORM FIELDS
        nameField = new RoundedTextField();
        emailField = new RoundedTextField();
        phoneField = new RoundedTextField();
        addressField = new RoundedTextField();

        main.add(createLabeledField("Full Name", nameField));
        main.add(Box.createVerticalStrut(15));
        main.add(createLabeledField("Email", emailField));
        main.add(Box.createVerticalStrut(15));
        main.add(createLabeledField("Phone Number", phoneField));
        main.add(Box.createVerticalStrut(15));
        main.add(createLabeledField("Address", addressField));
        main.add(Box.createVerticalStrut(30));

        // PAY BUTTON
        GradientButton payBtn = new GradientButton("Confirm & Pay", PURPLE, PURPLE_LIGHT);
        payBtn.setFont(new Font("Arial", Font.BOLD, 18));
        payBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Use direct references to fields
        payBtn.addActionListener(e -> {
            if (!validateForm(nameField, emailField, phoneField, addressField)) return;

            cart.clear(); // Clear cart
            new CheckoutSuccessPage(); // Open success page
            dispose();
        });

        main.add(payBtn);

        add(main);
        setVisible(true);
    }

    private boolean validateForm(JTextField name, JTextField email,
                                 JTextField phone, JTextField address) {

        if (name.getText().trim().isEmpty() ||
            email.getText().trim().isEmpty() ||
            phone.getText().trim().isEmpty() ||
            address.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(this,
                    "Please fill in all fields.",
                    "Missing Information",
                    JOptionPane.WARNING_MESSAGE);
            return false;
        }

        if (!email.getText().contains("@") || !email.getText().contains(".")) {
            JOptionPane.showMessageDialog(this,
                    "Enter a valid email address.",
                    "Invalid Email",
                    JOptionPane.WARNING_MESSAGE);
            return false;
        }

        if (!phone.getText().matches("\\d{8,12}")) {
            JOptionPane.showMessageDialog(this,
                    "Phone number must be digits (8–12).",
                    "Invalid Phone",
                    JOptionPane.WARNING_MESSAGE);
            return false;
        }

        return true;
    }

    // Creates a panel with a visible label above the given field
    private JPanel createLabeledField(String labelText, JTextField field) {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setOpaque(false);

        JLabel label = new JLabel(labelText);
        label.setFont(new Font("Arial", Font.PLAIN, 14));
        label.setForeground(Color.DARK_GRAY);

        panel.add(label, BorderLayout.NORTH);
        panel.add(field, BorderLayout.CENTER);

        return panel;
    }

    // Rounded text field without hiding label
    static class RoundedTextField extends JTextField {
        public RoundedTextField() {
            setFont(new Font("Arial", Font.PLAIN, 16));
            setBackground(Color.WHITE);
            setOpaque(false);
            setColumns(20);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(Color.WHITE);
            g2.fillRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);
            super.paintComponent(g);
            g2.dispose();
        }

        @Override
        protected void paintBorder(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setColor(Color.LIGHT_GRAY);
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            g2.drawRoundRect(0, 0, getWidth()-1, getHeight()-1, 20, 20);
            g2.dispose();
        }
    }

    // Gradient Button
    static class GradientButton extends JButton {

        Color start;
        Color end;

        public GradientButton(String text, Color start, Color end) {
            super(text);
            this.start = start;
            this.end = end;
            setContentAreaFilled(false);
            setFocusPainted(false);
            setForeground(Color.WHITE);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    Color tmp = GradientButton.this.start;
                    GradientButton.this.start = GradientButton.this.end;
                    GradientButton.this.end = tmp;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    Color tmp = GradientButton.this.start;
                    GradientButton.this.start = GradientButton.this.end;
                    GradientButton.this.end = tmp;
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);

            GradientPaint gp = new GradientPaint(0, 0, start, 0, getHeight(), end);
            g2.setPaint(gp);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);

            super.paintComponent(g);
            g2.dispose();
        }

        @Override
        protected void paintBorder(Graphics g) {
            // no border
        }
    }
}
