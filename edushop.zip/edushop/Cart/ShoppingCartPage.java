package Cart;

import courses.MyCoursesPage;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ShoppingCartPage extends JPanel {

    private JPanel itemsPanel;
    private JLabel totalLabel;

    public ShoppingCartPage() {
        setLayout(new BorderLayout());

        itemsPanel = new JPanel();
        itemsPanel.setLayout(new BoxLayout(itemsPanel, BoxLayout.Y_AXIS));

        JScrollPane scrollPane = new JScrollPane(itemsPanel);
        add(scrollPane, BorderLayout.CENTER);

        totalLabel = new JLabel("Total: 0 DA");
        totalLabel.setFont(new Font("Arial", Font.BOLD, 20));
        totalLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // FOOTER PANEL (TOTAL + CHECKOUT BUTTON)
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.add(totalLabel, BorderLayout.WEST);

        JButton checkoutBtn = new JButton("Proceed to Checkout");
        checkoutBtn.setFont(new Font("Arial", Font.BOLD, 16));

        // ✅ FIXED: CHECKOUT ACTION
        checkoutBtn.addActionListener(e -> {
            double total = 0;

            for (MyCoursesPage.Course c : cart.getItems()) {
                try {
                    String numeric = c.price.replaceAll("[^0-9.]", "");
                    total += Double.parseDouble(numeric);
                } catch (Exception ignored) {
                }
            }

            if (total <= 0) {
                JOptionPane.showMessageDialog(this,
                        "Your cart is empty.",
                        "Cannot Checkout",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            // ✅ Open the secure checkout window with the total
            new SecureCheckoutPage(total);
        });

        bottomPanel.add(checkoutBtn, BorderLayout.EAST);
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(bottomPanel, BorderLayout.SOUTH);
    }

    /** Refresh UI each time we open the cart */
    public void refresh() {
        loadCartItems();
    }

    /** Load all items visually */
    private void loadCartItems() {
        itemsPanel.removeAll();

        List<MyCoursesPage.Course> items = cart.getItems();
        double total = 0;

        for (MyCoursesPage.Course c : items) {

            JPanel card = new JPanel(new BorderLayout(10, 10));
            card.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.GRAY));
            card.setPreferredSize(new Dimension(450, 120));
            card.setBackground(Color.WHITE);

            JLabel imgLabel = new JLabel();
            imgLabel.setPreferredSize(new Dimension(120, 90));
            imgLabel.setHorizontalAlignment(SwingConstants.CENTER);

            try {
                ImageIcon rawIcon = new ImageIcon(
                        getClass().getResource("/courses/images/" + c.imageName)
                );

                Image scaled = rawIcon.getImage().getScaledInstance(120, 90, Image.SCALE_SMOOTH);
                imgLabel.setIcon(new ImageIcon(scaled));
            } catch (Exception ex) {
                imgLabel.setText("[No Image]");
            }

            card.add(imgLabel, BorderLayout.WEST);

            JPanel info = new JPanel(new GridLayout(2, 1));
            info.setBackground(Color.WHITE);

            JLabel nameLabel = new JLabel(c.title);
            nameLabel.setFont(new Font("Arial", Font.BOLD, 15));

            JLabel priceLabel = new JLabel(c.price);
            priceLabel.setFont(new Font("Arial", Font.PLAIN, 14));

            info.add(nameLabel);
            info.add(priceLabel);

            card.add(info, BorderLayout.CENTER);

            JButton removeBtn = new JButton("Remove");
            removeBtn.addActionListener(e -> {
                cart.remove(c);
                loadCartItems();
            });

            JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            btnPanel.setBackground(Color.WHITE);
            btnPanel.add(removeBtn);

            card.add(btnPanel, BorderLayout.EAST);

            itemsPanel.add(card);

            try {
                String numeric = c.price.replaceAll("[^0-9.]", "");
                total += Double.parseDouble(numeric);
            } catch (Exception ignored) { }
        }

        totalLabel.setText("Total: " + total + " DA");

        itemsPanel.revalidate();
        itemsPanel.repaint();
    }
}
