package Cart;

import courses.MyCoursesPage;
import java.util.ArrayList;
import java.util.List;

public class cart {

    private static final List<MyCoursesPage.Course> items = new ArrayList<>();

    public static void add(MyCoursesPage.Course c) {
        items.add(c);
    }

    public static void remove(MyCoursesPage.Course c) {
        items.remove(c);
    }

    public static List<MyCoursesPage.Course> getItems() {
        return new ArrayList<>(items); // prevents direct modification
    }

    public static void clear() {
        items.clear();
    }

    public static double getTotal() {
        double total = 0;
        for (MyCoursesPage.Course c : items) {
            try {
                String numeric = c.price.replaceAll("[^0-9.]", "");
                total += Double.parseDouble(numeric);
            } catch (Exception ignored) {}
        }
        return total;
    }
}
