package Cart;

import javax.swing.*;
import java.awt.*;

public class CheckoutSuccessPage extends JFrame {

    Color PURPLE = Color.decode("#8117eb");

    public CheckoutSuccessPage() {

        setTitle("Order Confirmed");
        setSize(420, 360);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 20, 30, 20));

        // Title
        JLabel title = new JLabel("✔ Payment Successful!");
        title.setFont(new Font("Arial", Font.BOLD, 26));
        title.setForeground(PURPLE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel msg = new JLabel("Thank you for your purchase.");
        msg.setFont(new Font("Arial", Font.PLAIN, 18));
        msg.setAlignmentX(Component.CENTER_ALIGNMENT);

        // ---- PAYMENT METHOD TITLE ----
        JLabel pm = new JLabel("Payment Method:");
        pm.setFont(new Font("Arial", Font.BOLD, 16));
        pm.setForeground(PURPLE);
        pm.setAlignmentX(Component.CENTER_ALIGNMENT);

        // ---- ICONS PANEL ----
        JPanel iconsRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 5));
        iconsRow.setBackground(Color.WHITE);

        // Load icons from resources
        iconsRow.add(loadIcon("/courses/images/visa.png"));
        iconsRow.add(loadIcon("/courses/images/mastercard.png"));
        iconsRow.add(loadIcon("/courses/images/paypal.png"));
        iconsRow.add(loadIcon("/courses/images/cib.png"));
        iconsRow.add(loadIcon("/courses/images/edahabia.png"));

        // Add components
        panel.add(title);
        panel.add(Box.createVerticalStrut(15));
        panel.add(msg);
        panel.add(Box.createVerticalStrut(25));
        panel.add(pm);
        panel.add(Box.createVerticalStrut(12));
        panel.add(iconsRow);

        add(panel);
        setVisible(true);
    }

    /**
     * Utility method to safely load images.
     */
    private JLabel loadIcon(String resourcePath) {
        try {
            ImageIcon raw = new ImageIcon(getClass().getResource(resourcePath));
            Image scaled = raw.getImage().getScaledInstance(45, 45, Image.SCALE_SMOOTH);
            return new JLabel(new ImageIcon(scaled));
        } catch (Exception e) {
            JLabel fail = new JLabel("[img]");
            fail.setForeground(Color.GRAY);
            return fail;
        }
    }
}
