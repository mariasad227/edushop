package courses;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import Cart.cart;

public class MyCoursesPage extends JPanel {

    // Primary UI color
    private final Color primary = Color.decode("#8117eb");
    private final Color primaryHover = new Color(129, 23, 235, 200); 
    private final Color borderTint = new Color(185, 160, 230);

    public MyCoursesPage() {
        super(new BorderLayout(12,12));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(12,12,12,12));

        JLabel title = new JLabel("My Courses");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 18f));
        title.setForeground(primary);  // Apply new color
        add(title, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(0, 3, 12, 12));
        grid.setBackground(Color.WHITE);

        Course[] courses = new Course[] {
            new Course("Complete Web Dev", "HTML, CSS, JS, Backend", "4500", 4.8, "webdev.png"),
            new Course("Python for Data Science", "Pandas, NumPy, ML intro", "5200", 4.6, "python.png"),
            new Course("Java Fundamentals", "OOP, Threads, GUI", "3800", 4.4, "java.png"),
            new Course("React Advanced", "Hooks, Performance", "4900", 4.7, "react.png"),
            new Course("Node.js & Express", "APIs, Auth, DB", "3600", 4.3, "node.png"),
            new Course("UI/UX Basics", "Design & Prototyping", "2900", 4.1, "uiux.png")
        };

        for (Course c : courses) {
            grid.add(createCourseCard(c));
        }

        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setBackground(Color.WHITE);
        wrap.add(grid, BorderLayout.NORTH);

        JScrollPane scroll = new JScrollPane(wrap,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.setBorder(null);

        add(scroll, BorderLayout.CENTER);

        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(Color.WHITE);
        footer.setBorder(new EmptyBorder(8,0,0,0));

        JLabel summary = new JLabel(courses.length + " courses found");
        summary.setFont(summary.getFont().deriveFont(Font.PLAIN, 13f));
        footer.add(summary, BorderLayout.WEST);

        JComboBox<String> sort = new JComboBox<>(
            new String[] {"Sort: Popular", "Price: Low → High", "Price: High → Low", "Newest"});
        footer.add(sort, BorderLayout.EAST);

        add(footer, BorderLayout.SOUTH);
    }


    private JComponent createCourseCard(final Course c) {
        JPanel card = new JPanel(new BorderLayout(8,8));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borderTint),
                new EmptyBorder(10,10,10,10)
        ));
        card.setBackground(Color.WHITE);
        card.setPreferredSize(new Dimension(240, 240));

        JLabel img = new JLabel();
        img.setHorizontalAlignment(SwingConstants.CENTER);
        img.setPreferredSize(new Dimension(200, 120));

        try {
            ImageIcon raw = new ImageIcon(
                getClass().getResource("/courses/images/" + c.imageName)
            );
            Image scaled = raw.getImage().getScaledInstance(200, 120, Image.SCALE_SMOOTH);
            img.setIcon(new ImageIcon(scaled));
        } catch (Exception ex) {
            img.setText("[No Image]");
        }

        card.add(img, BorderLayout.NORTH);

        JLabel name = new JLabel("<html><b>" + c.title + "</b></html>");
        name.setFont(name.getFont().deriveFont(14f));
        name.setForeground(primary);

        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(Color.WHITE);

        JLabel desc = new JLabel("<html><small>" + c.shortDesc + "</small></html>");
        desc.setBorder(new EmptyBorder(4,0,6,0));

        JPanel rp = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        rp.setBackground(Color.WHITE);

        JLabel rating = new JLabel(String.format("★ %.1f", c.rating));
        JLabel price = new JLabel(c.price + " DA");
        price.setFont(price.getFont().deriveFont(Font.BOLD, 13f));
        price.setBorder(new EmptyBorder(0,12,0,0));

        rp.add(rating);
        rp.add(price);

        center.add(name, BorderLayout.NORTH);
        center.add(desc, BorderLayout.CENTER);
        center.add(rp, BorderLayout.SOUTH);

        card.add(center, BorderLayout.CENTER);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        actions.setBackground(Color.WHITE);

        // SECONDARY BUTTON – OUTLINE STYLE
        JButton details = new JButton("Details");
        details.setBackground(Color.WHITE);
        details.setForeground(primary);
        details.setBorder(BorderFactory.createLineBorder(primary, 1));

        details.addActionListener(e ->
            JOptionPane.showMessageDialog(card,
                c.title + "\n\n" + c.shortDesc + "\nPrice: " + c.price + " DA",
                "Course details",
                JOptionPane.INFORMATION_MESSAGE));

        // PRIMARY BUTTON – SOLID PURPLE
        JButton add = new JButton("Add to cart");
        add.setBackground(primary);
        add.setForeground(Color.WHITE);
        add.setOpaque(true);
        add.setBorder(BorderFactory.createLineBorder(primary.darker()));

        // Hover feedback
        add.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                add.setBackground(primaryHover);
            }
            @Override
            public void mouseExited(MouseEvent e) {
                add.setBackground(primary);
            }
        });

        add.addActionListener(e -> {
            cart.add(c);
            JOptionPane.showMessageDialog(card, c.title + " added to cart.");
        });

        actions.add(details);
        actions.add(add);

        card.add(actions, BorderLayout.SOUTH);

        return card;
    }


    public static class Course {
        public String title, shortDesc, price, imageName;
        public double rating;

        public Course(String t, String s, String p, double r, String img) {
            title = t;
            shortDesc = s;
            price = p;
            rating = r;
            imageName = img;
        }
    }
}
