package data;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;


public class FileDatabase {

    private final Path filePath;
    private int nextUserId = 1, nextCourseId = 1, nextPaymentId = 1, nextCertId = 0;

    public List<User> users = new ArrayList<>();
    public List<Course> courses = new ArrayList<>();
    public List<CartItem> carts = new ArrayList<>();
    public List<PaymentRecord> payments = new ArrayList<>();
    public List<CertificateRecord> certificates = new ArrayList<>();

    public FileDatabase(String path) throws IOException {
        this.filePath = Paths.get(path);
        if (Files.notExists(this.filePath)) {
            // create basic file
            Files.createDirectories(this.filePath.getParent() == null ? Paths.get("") : this.filePath.getParent());
            try (BufferedWriter bw = Files.newBufferedWriter(this.filePath)) {
                bw.write("# NEXT_IDS\n");
                bw.write("userId=1\ncourseId=1\npaymentId=1\ncertificateId=0\n\n");
                bw.write("[USERS]\n\n[COURSES]\n\n[CARTS]\n\n[PAYMENTS]\n\n[CERTIFICATES]\n");
            }
        }
        loadAll();
    }

    // ---------- Loading
    public synchronized void loadAll() {
        users.clear(); courses.clear(); carts.clear(); payments.clear(); certificates.clear();
        try (BufferedReader br = Files.newBufferedReader(filePath)) {
            String line;
            String section = "";
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                if (line.startsWith("[") && line.endsWith("]")) {
                    section = line;
                    continue;
                }
                if (section.isEmpty()) {
                    // maybe NEXT_IDS block lines
                    if (line.startsWith("userId=")) nextUserId = Integer.parseInt(line.split("=")[1]);
                    if (line.startsWith("courseId=")) nextCourseId = Integer.parseInt(line.split("=")[1]);
                    if (line.startsWith("paymentId=")) nextPaymentId = Integer.parseInt(line.split("=")[1]);
                    if (line.startsWith("certificateId=")) nextCertId = Integer.parseInt(line.split("=")[1]);
                    continue;
                }

                switch (section) {
                    case "[USERS]":
                        // format: id;name;email
                        String[] u = line.split(";", 3);
                        if (u.length >= 3) users.add(new User(Integer.parseInt(u[0]), u[1], u[2]));
                        break;
                    case "[COURSES]":
                        // format: id;title;price
                        String[] c = line.split(";", 3);
                        if (c.length >= 3) courses.add(new Course(Integer.parseInt(c[0]), c[1], Double.parseDouble(c[2])));
                        break;
                    case "[CARTS]":
                        // format: userId|courseId|quantity
                        String[] ci = line.split("\\|", 3);
                        if (ci.length >= 3) carts.add(new CartItem(Integer.parseInt(ci[0]), Integer.parseInt(ci[1]), Integer.parseInt(ci[2])));
                        break;
                    case "[PAYMENTS]":
                        // format: paymentId;userId;amount;method;status
                        String[] p = line.split(";", 5);
                        if (p.length >= 5) payments.add(new PaymentRecord(Integer.parseInt(p[0]), Integer.parseInt(p[1]), Double.parseDouble(p[2]), p[3], p[4]));
                        break;
                    case "[CERTIFICATES]":
                        // format: certId;userId;courseId;filePath
                        String[] cr = line.split(";", 4);
                        if (cr.length >= 4) certificates.add(new CertificateRecord(Integer.parseInt(cr[0]), Integer.parseInt(cr[1]), Integer.parseInt(cr[2]), cr[3]));
                        break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // ---------- Saving (atomic)
    private synchronized void saveAll() {
        try {
            Path tmp = Files.createTempFile("data", ".tmp");
            try (BufferedWriter bw = Files.newBufferedWriter(tmp)) {
                bw.write("# NEXT_IDS\n");
                bw.write("userId=" + nextUserId + "\n");
                bw.write("courseId=" + nextCourseId + "\n");
                bw.write("paymentId=" + nextPaymentId + "\n");
                bw.write("certificateId=" + nextCertId + "\n\n");

                bw.write("[USERS]\n");
                for (User u : users) {
                    bw.write(u.id + ";" + u.name + ";" + u.email + "\n");
                }
                bw.write("\n[COURSES]\n");
                for (Course c : courses) {
                    bw.write(c.id + ";" + c.title + ";" + c.price + "\n");
                }
                bw.write("\n[CARTS]\n");
                for (CartItem it : carts) {
                    bw.write(it.userId + "|" + it.courseId + "|" + it.quantity + "\n");
                }
                bw.write("\n[PAYMENTS]\n");
                for (PaymentRecord pr : payments) {
                    bw.write(pr.paymentId + ";" + pr.userId + ";" + pr.amount + ";" + pr.method + ";" + pr.status + "\n");
                }
                bw.write("\n[CERTIFICATES]\n");
                for (CertificateRecord cr : certificates) {
                    bw.write(cr.certId + ";" + cr.userId + ";" + cr.courseId + ";" + cr.filePath + "\n");
                }
            }
            // move temp to real file (atomic on many OS)
            Files.move(tmp, filePath, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // ---------- API simple
    public synchronized User addUser(String name, String email) {
        User u = new User(nextUserId++, name, email);
        users.add(u);
        saveAll();
        return u;
    }

    public synchronized Course addCourse(String title, double price) {
        Course c = new Course(nextCourseId++, title, price);
        courses.add(c);
        saveAll();
        return c;
    }

    public synchronized void addToCart(int userId, int courseId, int quantity) {
        // if same item exists, increase quantity
        for (CartItem it : carts) {
            if (it.userId == userId && it.courseId == courseId) {
                it.quantity += quantity;
                saveAll();
                return;
            }
        }
        carts.add(new CartItem(userId, courseId, quantity));
        saveAll();
    }

    public synchronized void removeFromCart(int userId, int courseId) {
        carts.removeIf(it -> it.userId == userId && it.courseId == courseId);
        saveAll();
    }

    public synchronized double getCartTotal(int userId) {
        double sum = 0;
        for (CartItem it : carts) {
            if (it.userId == userId) {
                Course c = findCourse(it.courseId);
                if (c != null) sum += c.price * it.quantity;
            }
        }
        return sum;
    }

    private Course findCourse(int courseId) {
        for (Course c : courses) if (c.id == courseId) return c;
        return null;
    }

    public synchronized PaymentRecord checkout(int userId, String method) {
        double amount = getCartTotal(userId);
        if (amount <= 0) return null;
        PaymentRecord p = new PaymentRecord(nextPaymentId++, userId, amount, method, "SUCCESS");
        payments.add(p);
        // clear user's cart
        carts.removeIf(it -> it.userId == userId);
        saveAll();
        return p;
    }

    public synchronized CertificateRecord generateCertificate(int userId, int courseId) {
        // create a simple text certificate file
        int certId = nextCertId++;
        String certDir = "certs";
        try {
            Files.createDirectories(Paths.get(certDir));
        } catch (IOException e) {
            e.printStackTrace();
        }
        String fileName = certDir + "/cert_" + certId + "_" + userId + "_" + courseId + ".txt";
        String content = "Certificate of Completion\n\nUser ID: " + userId + "\nCourse ID: " + courseId + "\nCertificate ID: " + certId + "\n\nCongratulations!";

        try {
            Files.write(Paths.get(fileName), content.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        CertificateRecord cr = new CertificateRecord(certId, userId, courseId, fileName);
        certificates.add(cr);
        saveAll();
        return cr;
    }

    // helper: get user's cart items
    public synchronized List<CartItem> getCartForUser(int userId) {
        return carts.stream().filter(it -> it.userId == userId).collect(Collectors.toList());
    }
}
