package data;
public class CartItem {
    public int userId;
    public int courseId;
    public int quantity;

    public CartItem(int userId, int courseId, int quantity) {
        this.userId = userId; this.courseId = courseId; this.quantity = quantity;
    }
}
