package data;
public class PaymentRecord {
    public int paymentId;
    public int userId;
    public double amount;
    public String method;
    public String status;

    public PaymentRecord(int paymentId, int userId, double amount, String method, String status) {
        this.paymentId = paymentId; this.userId = userId; this.amount = amount; this.method = method; this.status = status;
    }
}
