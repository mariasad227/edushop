
package data;
public class Course {
    public int id;
    public String title;
    public double price;

    public Course(int id, String title, double price) {
        this.id = id; this.title = title; this.price = price;
    }
}
